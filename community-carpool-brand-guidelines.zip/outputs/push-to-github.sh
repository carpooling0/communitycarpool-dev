#!/bin/bash

# Community Carpool Brand Guidelines - Push to GitHub
# Run this in Claude Code terminal to deploy the brand site

echo "🚀 Community Carpool Brand Guidelines - GitHub Push"
echo "=================================================="
echo ""

# Step 1: Navigate to outputs directory
echo "Step 1: Preparing files..."
cd /mnt/user-data/outputs || { echo "❌ Error: Could not find outputs directory"; exit 1; }
echo "✓ In outputs directory"

# Step 2: Configure git (if not already done)
echo ""
echo "Step 2: Configuring git..."
git config --global user.email "brand@communitycarpool.org" 2>/dev/null
git config --global user.name "Community Carpool" 2>/dev/null
echo "✓ Git configured"

# Step 3: Check if repo already initialized
echo ""
echo "Step 3: Initializing repository..."
if [ -d ".git" ]; then
    echo "✓ Repository already initialized"
else
    git init
    echo "✓ Repository initialized"
fi

# Step 4: Add all files
echo ""
echo "Step 4: Staging files..."
git add .
echo "✓ All files staged"

# Step 5: Create commit
echo ""
echo "Step 5: Creating commit..."
git commit -m "Initial commit: Community Carpool Brand Guidelines" 2>/dev/null || \
git commit -m "Update: Brand Guidelines" 2>/dev/null || \
{ echo "Note: Files already committed"; }
echo "✓ Commit created"

# Step 6: Set up remote
echo ""
echo "Step 6: Adding GitHub remote..."
git remote remove origin 2>/dev/null
git remote add origin https://github.com/communitycarpool/brand.git
echo "✓ Remote added"

# Step 7: Rename branch
echo ""
echo "Step 7: Setting up main branch..."
git branch -M main
echo "✓ Branch set to main"

# Step 8: Push to GitHub
echo ""
echo "Step 8: Pushing to GitHub..."
echo "=================================================="
git push -u origin main
PUSH_STATUS=$?
echo "=================================================="

if [ $PUSH_STATUS -eq 0 ]; then
    echo ""
    echo "✅ SUCCESS! Brand guidelines pushed to GitHub"
    echo ""
    echo "📍 Your brand site is now live at:"
    echo "   https://communitycarpool.github.io/brand/"
    echo ""
    echo "⚠️  Note: It may take 1-2 minutes for GitHub Pages to build and deploy"
    echo ""
    echo "Next steps:"
    echo "1. Wait 1-2 minutes"
    echo "2. Visit https://communitycarpool.github.io/brand/"
    echo "3. You should see the professional brand home page"
    echo ""
else
    echo ""
    echo "❌ Error pushing to GitHub"
    echo ""
    echo "Possible issues:"
    echo "1. GitHub authentication not set up"
    echo "2. Repository doesn't exist yet"
    echo "3. You don't have push access to the repo"
    echo ""
    echo "Solutions:"
    echo "1. Make sure you're logged into GitHub in your browser"
    echo "2. Verify the repo exists: https://github.com/communitycarpool/brand"
    echo "3. Ask the repo owner to add you as a collaborator"
    echo ""
fi
