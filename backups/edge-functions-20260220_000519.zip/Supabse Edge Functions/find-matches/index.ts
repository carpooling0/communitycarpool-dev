import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const supabase = createClient(Deno.env.get('DB_URL')!, Deno.env.get('DB_SERVICE_KEY')!)
const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' }

function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLon = (lon2 - lon1) * Math.PI / 180
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon/2) * Math.sin(dLon/2)
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const { submissionId } = await req.json()

    // Select lat/lng as floats via ST_X/ST_Y to avoid WKB parsing issues
    const { data: sub, error: subError } = await supabase.rpc('get_submission_coords', { p_id: submissionId }).single()
    if (subError || !sub) throw new Error('Submission not found')

    const fromLat = sub.from_lat as number
    const fromLng = sub.from_lng as number
    const toLat = sub.to_lat as number
    const toLng = sub.to_lng as number
    const radiusMeters = (sub.distance_pref || 3) * 1000

    const { data: candidates } = await supabase.rpc('find_nearby_users', {
      user_from_lat: fromLat, user_from_lng: fromLng,
      user_to_lat: toLat, user_to_lng: toLng,
      radius_meters: radiusMeters,
      exclude_email: sub.email, exclude_id: submissionId,
      exclude_org_id: sub.org_id
    })

    if (!candidates || candidates.length === 0) {
      return new Response(JSON.stringify({ success: true, matchesFound: 0 }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    let matchesFound = 0

    for (const candidate of candidates) {
      // Check if match already exists
      const minId = Math.min(submissionId, candidate.submission_id)
      const maxId = Math.max(submissionId, candidate.submission_id)
      const { data: existing } = await supabase.from('matches')
        .select('match_id').eq('sub_a_id', minId).eq('sub_b_id', maxId).single()
      if (existing) continue

      const candFromLat = candidate.from_lat as number
      const candFromLng = candidate.from_lng as number
      const candToLat = candidate.to_lat as number
      const candToLng = candidate.to_lng as number

      // 2-call alignment optimization
      const distAC = haversineDistance(fromLat, fromLng, candFromLat, candFromLng)
      const distAD = haversineDistance(fromLat, fromLng, candToLat, candToLng)
      const isDirect = distAC <= distAD

      const startDist = isDirect ? distAC : haversineDistance(fromLat, fromLng, candToLat, candToLng)
      const endDist = isDirect 
        ? haversineDistance(toLat, toLng, candToLat, candToLng)
        : haversineDistance(toLat, toLng, candFromLat, candFromLng)

      const maxRadius = Math.max(sub.distance_pref || 3, candidate.distance_pref || 3)

      if (startDist <= maxRadius && endDist <= maxRadius) {
        const matchStrength = Math.round(Math.max(0, Math.min(100, 100 * (1 - (startDist + endDist) / (2 * maxRadius * 2)))))

        const { error: matchError } = await supabase.from('matches').insert({
          sub_a_id: minId, sub_b_id: maxId,
          match_strength: matchStrength, status: 'new', email_sent: false
        })

        if (!matchError) {
          matchesFound++
          await supabase.from('events').insert({
            event_type: 'match_detected', submission_id: submissionId,
            metadata: { matched_with: candidate.submission_id, start_dist: Math.round(startDist * 10) / 10, end_dist: Math.round(endDist * 10) / 10, match_strength: matchStrength }
          })
        }
      }
    }

    return new Response(JSON.stringify({ success: true, matchesFound }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  } catch (err) {
    console.error('find-matches error:', err)
    return new Response(JSON.stringify({ success: false, error: err.message }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 })
  }
})
