import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const supabase = createClient(Deno.env.get('DB_URL')!, Deno.env.get('DB_SERVICE_KEY')!)
const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' }

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const { token, matchId, submissionId, interest } = await req.json()

    const { data: user, error: userError } = await supabase.from('users')
      .select('user_id, name, email').eq('match_page_token', token).single()
    if (userError || !user) return new Response(JSON.stringify({ success: false, error: 'Invalid token' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 })

    // name/email now live in users table, joined through submissions
    const { data: match } = await supabase.from('matches').select(`
      match_id, status, sub_a_id, sub_b_id, interest_a, interest_b,
      sub_a:submissions!sub_a_id (submission_id, user_id, journey_num, from_location, to_location, users(name, email, match_page_token)),
      sub_b:submissions!sub_b_id (submission_id, user_id, journey_num, from_location, to_location, users(name, email, match_page_token))
    `).eq('match_id', matchId).single()

    if (!match) return new Response(JSON.stringify({ success: false, error: 'Match not found' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 404 })

    const isSubA = match.sub_a.submission_id === submissionId
    const mySub = isSubA ? match.sub_a : match.sub_b
    const otherSub = isSubA ? match.sub_b : match.sub_a

    if (mySub.user_id !== user.user_id) return new Response(JSON.stringify({ success: false, error: 'Unauthorized' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 403 })

    // Check if other side already declined
    const otherInterest = isSubA ? match.interest_b : match.interest_a
    if (otherInterest === 'no') return new Response(JSON.stringify({ success: false, error: 'The other user has declined this match.' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 })

    // Determine new status
    const myInterestField = isSubA ? 'interest_a' : 'interest_b'
    let newStatus = match.status
    if (interest === 'no') newStatus = 'failed'
    else if (interest === 'yes' && otherInterest === 'yes') newStatus = 'mutual_confirmed'
    else if (interest === 'yes') newStatus = 'interest_expressed'

    await supabase.from('matches').update({ [myInterestField]: interest, status: newStatus, is_mutual_click: newStatus === 'mutual_confirmed' }).eq('match_id', matchId)

    await supabase.from('events').insert({
      event_type: interest === 'yes' ? 'match_interest_expressed' : 'match_declined',
      user_id: user.user_id, submission_id: submissionId, match_id: matchId,
      metadata: { interest, other_submission_id: otherSub.submission_id }
    })

    // Handle mutual match - reveal contacts immediately (no email - users see it on the dashboard)
    if (newStatus === 'mutual_confirmed') {
      await supabase.from('matches').update({ status: 'contact_revealed' }).eq('match_id', matchId)
      await supabase.from('events').insert([
        { event_type: 'mutual_match_confirmed', user_id: user.user_id, match_id: matchId },
        { event_type: 'contact_details_revealed', match_id: matchId }
      ])
    }

    return new Response(JSON.stringify({ success: true, newStatus, isMutual: newStatus === 'mutual_confirmed' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  } catch (err) {
    return new Response(JSON.stringify({ success: false, error: err.message }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 })
  }
})
